import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mapbox_api/features/owners/providers/owners_providers.dart';

class OwnerParkingFormPage extends ConsumerStatefulWidget {
  final String? parkingId; // null = crear, !null = editar
  const OwnerParkingFormPage({super.key, this.parkingId});

  @override
  ConsumerState<OwnerParkingFormPage> createState() =>
      _OwnerParkingFormPageState();
}

class _OwnerParkingFormPageState extends ConsumerState<OwnerParkingFormPage> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _lat = TextEditingController();
  final _lng = TextEditingController();
  final _spaces = TextEditingController(text: '12');
  final _pricePerHour = TextEditingController(text: '10');
  final _descripcion = TextEditingController();

  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _lat.dispose();
    _lng.dispose();
    _spaces.dispose();
    _pricePerHour.dispose();
    _descripcion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.parkingId == null ? 'Crear Parqueo' : 'Editar Parqueo',
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _form,
            child: ListView(
              children: [
                TextFormField(
                  controller: _name,
                  decoration: const InputDecoration(labelText: 'Nombre'),
                  validator:
                      (v) =>
                          (v == null || v.trim().isEmpty) ? 'Requerido' : null,
                ),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _lat,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(labelText: 'Latitud'),
                        validator:
                            (v) =>
                                (double.tryParse(v ?? '') == null)
                                    ? 'Inválido'
                                    : null,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        controller: _lng,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'Longitud',
                        ),
                        validator:
                            (v) =>
                                (double.tryParse(v ?? '') == null)
                                    ? 'Inválido'
                                    : null,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _spaces,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'N. espacios',
                        ),
                        validator:
                            (v) =>
                                (int.tryParse(v ?? '') ?? 0) <= 0
                                    ? 'Inválido'
                                    : null,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextFormField(
                        controller: _pricePerHour,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Precio por hora (Q)',
                        ),
                        validator:
                            (v) =>
                                (int.tryParse(v ?? '') ?? -1) < 0
                                    ? 'Inválido'
                                    : null,
                      ),
                    ),
                  ],
                ),
                TextFormField(
                  controller: _descripcion,
                  decoration: const InputDecoration(
                    labelText: 'Descripción (opcional)',
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saving ? null : _onSave,
                    child: Text(_saving ? 'Guardando...' : 'Guardar'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _onSave() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);

    try {
      final upsert = ref.read(upsertParkingProvider);
      final id = await upsert(
        parkingId: widget.parkingId,
        name: _name.text.trim(),
        lat: double.parse(_lat.text.trim()),
        lng: double.parse(_lng.text.trim()),
        spaces: int.parse(_spaces.text.trim()),
        pricePerHour: int.parse(_pricePerHour.text.trim()),
        descripcion:
            _descripcion.text.trim().isEmpty ? null : _descripcion.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Parqueo guardado (id: $id)')));
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }
}
