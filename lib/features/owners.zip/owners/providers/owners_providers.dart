import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'package:mapbox_api/features/core/providers/firebase_providers.dart';

/// ---------------------------------------------------------------------------
/// 1) Crear dueño + parqueo con fotos + sembrar espacios
///    - Crea doc en /parking/{id} con ownerID
///    - Sube imágenes a Storage -> coverUrl/photos
///    - Siembra /parkings/{id}/spaces/{1..N}
/// ---------------------------------------------------------------------------
final createOwnerAndParkingProvider = Provider<
  Future<void> Function({
    required String uid,
    required String companyName,
    required String parkingName,
    required String email,
    required String phone,
    required String address,
    required int capacity,
    required String description,
    required double lat,
    required double lng,
    required List<XFile> images,
    required int price, // pricePerHour
  })
>((ref) {
  final db = ref.watch(firestoreProvider);
  final storage = ref.watch(storageProvider);

  return ({
    required String uid,
    required String companyName,
    required String parkingName,
    required String email,
    required String phone,
    required String address,
    required int capacity,
    required String description,
    required double lat,
    required double lng,
    required List<XFile> images,
    required int price,
  }) async {
    if (capacity <= 0) throw ArgumentError('La capacidad debe ser mayor a 0.');
    if (price < 0)
      throw ArgumentError('El precio por hora no puede ser negativo.');
    if (images.isEmpty) throw ArgumentError('Debes subir al menos una imagen.');

    // 1) Crea el doc primero para que las reglas puedan comprobar ownerID
    final parkingRef = db.collection('parking').doc();
    final parkingId = parkingRef.id;

    await parkingRef.set({
      'ownerID': uid,
      'name': parkingName,
      'lat': lat,
      'lng': lng,
      'spaces': capacity,
      'pricePerHour': price,
      'descripcion': description.isEmpty ? null : description,
      'address': address,
      'email': email,
      'phone': phone,
      'createdAt': FieldValue.serverTimestamp(),
      // fallback para UIs antiguas:
      'price': price,
    }, SetOptions(merge: true));

    // 2) Sube imágenes
    final List<String> photoUrls = [];
    for (int i = 0; i < images.length; i++) {
      final x = images[i];
      final bytes = await x.readAsBytes();
      final path = 'parking/$parkingId/photos/$i.jpg';
      final task = await storage
          .ref(path)
          .putData(bytes, SettableMetadata(contentType: 'image/jpeg'));
      final url = await task.ref.getDownloadURL();
      photoUrls.add(url);
    }
    final coverUrl = photoUrls.first;

    // 3) Actualiza coverUrl/photos
    await parkingRef.set({
      'coverUrl': coverUrl,
      'photos': photoUrls,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    // 4) Siembra espacios
    final spacesColl = db
        .collection('parkings')
        .doc(parkingId)
        .collection('spaces');
    final batch = db.batch();
    for (int i = 1; i <= capacity; i++) {
      batch.set(spacesColl.doc('$i'), {
        'status': 'free',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
    await batch.commit();

    // 5) Marca al usuario como owner (opcional)
    final userRef = db.collection('users').doc(uid);
    await userRef.set({
      'companyName': companyName,
      'role': 'owner',
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  };
});

/// ---------------------------------------------------------------------------
/// 2) Upsert simple del parqueo (crear/editar campos básicos)
///    - No maneja imágenes.
///    - Si [parkingId] es null -> crea, si no -> actualiza.
/// ---------------------------------------------------------------------------
final upsertParkingProvider = Provider<
  Future<String> Function({
    String? parkingId,
    required String name,
    required double lat,
    required double lng,
    required int spaces,
    required int pricePerHour,
    String? descripcion,
  })
>((ref) {
  final db = ref.watch(firestoreProvider);

  return ({
    String? parkingId,
    required String name,
    required double lat,
    required double lng,
    required int spaces,
    required int pricePerHour,
    String? descripcion,
  }) async {
    if (spaces <= 0) {
      throw ArgumentError('N. de espacios debe ser mayor a 0.');
    }
    if (pricePerHour < 0) {
      throw ArgumentError('Precio por hora no puede ser negativo.');
    }

    final docRef =
        (parkingId == null || parkingId.isEmpty)
            ? db.collection('parking').doc()
            : db.collection('parking').doc(parkingId);

    final data = <String, dynamic>{
      'name': name,
      'lat': lat,
      'lng': lng,
      'spaces': spaces,
      'pricePerHour': pricePerHour,
      // fallback para UIs que todavía leen 'price'
      'price': pricePerHour,
      if (descripcion != null && descripcion.trim().isNotEmpty)
        'descripcion': descripcion.trim(),
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (parkingId == null || parkingId.isEmpty) {
      data['createdAt'] = FieldValue.serverTimestamp();
    }

    await docRef.set(data, SetOptions(merge: true));
    return docRef.id;
  };
});
